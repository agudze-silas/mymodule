from setuptools import setup, find_packages

setup(
    name="mymodule",
    version = "0.1",
    author="KSilas"
)